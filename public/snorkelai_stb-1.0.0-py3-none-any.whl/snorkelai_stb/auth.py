#!/usr/bin/env python3
"""Main CLI entry point"""

import webbrowser

import click

from snorkelai_stb.submissions import submissions
from snorkelai_stb.utils import set_api_key


@click.group()
def cli():
    """Snorkel Terminal-Bench CLI - Manage Terminal-Bench task submissions"""
    pass


cli.add_command(submissions)


@cli.command()
@click.option(
    "--env",
    type=click.Choice(["prod", "dev", "staging"], case_sensitive=False),
    default="prod",
    hidden=True,
    help="Environment to authenticate against",
)
def login(env):
    """Authenticate with Snorkel Terminal-Bench and store API key"""
    # Build the URL to the API key page
    env_urls = {
        "prod": "https://experts.snorkel-ai.com",
        "dev": "https://experts-dev.snorkel-ai.com",
        "staging": "https://experts-stg.snorkel-ai.com",
    }
    base_url = env_urls.get(env.lower(), env_urls["prod"])
    api_key_url = f"{base_url}/home"

    click.echo(f"🔐 Opening browser: {api_key_url}")

    # Try to open the browser
    try:
        webbrowser.open(api_key_url)
    except Exception:
        pass  # URL already shown above

    click.echo("Paste your API key below:")

    # Prompt for API key
    api_key = click.prompt("API Key", hide_input=True).strip()
    if not api_key:
        raise click.ClickException("API key cannot be empty")

    # Store in global config
    try:
        set_api_key(api_key)
        click.echo("✓ Logged in")
    except Exception as e:
        raise click.ClickException(f"Failed to save API key: {e}") from e
