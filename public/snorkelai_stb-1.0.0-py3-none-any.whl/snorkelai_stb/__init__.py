"""Snorkel Terminal-Bench - Manage Terminal-Bench task submissions"""

from snorkelai_stb.auth import cli

__version__ = "0.2.0"
__all__ = ["cli"]
