#!/usr/bin/env python3
"""CLI commands for submissions"""

import tempfile
import uuid
from datetime import datetime
from pathlib import Path

import click

from snorkelai_stb.utils import (
    FEEDBACK_TIMEOUT,
    config_file_exists,
    create_feedback,
    create_submission,
    get_api_key,
    get_assignment_id,
    get_assignment_task_id,
    get_feedback_button_info,
    get_project_task_type,
    get_submission_state,
    list_submission_ids,
    read_config_file,
    request_s3_presigned_url,
    upload_to_s3,
    write_config_file,
    zip_folder,
)


def _process_submission(
    api_key: str,
    project_id: str,
    env: str,
    folder_path: Path,
    is_update: bool,
    submission_id: str | None = None,
    dry_run: bool = False,
) -> int:
    """
    Common logic for creating or updating a submission.

    Args:
        api_key: API key for authentication
        project_id: Project ID
        env: Environment (prod, dev, or staging)
        folder_path: Path to the folder to submit
        is_update: True for update operations, False for create operations
        submission_id: Optional submission ID for updates
        dry_run: If True, only create zip file without uploading

    Returns:
        Exit code (0 for success)
    """
    operation = "Updating" if is_update else "Creating"

    click.echo(f"{'🔄' if is_update else '📦'} {operation} submission")
    if dry_run:
        click.echo("   ⚠️  DRY RUN MODE - No actual upload will occur")
    if submission_id:
        click.echo(f"   Submission ID: {submission_id}")
    click.echo(f"   From folder: {folder_path}")
    click.echo(f"   Project ID: {project_id}")
    click.echo(f"   Environment: {env}")

    # For updates, validate that the submission is in NEEDS_REVISION state
    if submission_id and not dry_run:
        try:
            current_state = get_submission_state(
                project_id=project_id,
                submission_id=submission_id,
                api_key=api_key,
                env=env,
            )
            if current_state != "NEEDS_REVISION":
                raise click.ClickException(
                    f"Cannot update: submission is in {current_state} state "
                    f"(must be NEEDS_REVISION)"
                )
        except click.ClickException:
            raise
        except ValueError as e:
            raise click.ClickException(str(e)) from e
        except Exception as e:
            raise click.ClickException(
                f"Failed to validate submission state: {e}"
            ) from e

    # Create a zip file in temp directory with random name + timestamp
    random_id = uuid.uuid4().hex[:8]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"submission_{random_id}_{timestamp}.zip"
    zip_path = Path(tempfile.gettempdir()) / zip_filename

    try:
        click.echo("\n📦 Zipping folder contents...")
        zip_folder(folder_path, zip_path)
        click.echo(f"✓ Created zip file: {zip_path}")
        click.echo(f"   Size: {zip_path.stat().st_size / 1024:.2f} KB")

        # In dry-run mode, stop here and clean up
        if dry_run:
            click.echo("\n✓ DRY RUN complete - no upload performed")
            if zip_path.exists():
                zip_path.unlink()
            return 0

        # Fetch the task type from the project
        try:
            task_type_str = get_project_task_type(project_id, api_key, env)
        except Exception as e:
            raise click.ClickException(f"Failed to fetch project task type: {e}") from e

        # For updates, use the provided submission_id; for creates, fetch assignment IDs
        if submission_id:
            # Use the provided submission ID for updates
            submission_task_id = submission_id

            # Fetch the correct assignment_id for S3 upload
            try:
                assignment_id = get_assignment_id(
                    project_id, submission_id, api_key, env
                )
            except Exception as e:
                raise click.ClickException(f"Failed to fetch assignment ID: {e}") from e
        else:
            # Fetch or create assignment task_id and assignment_id
            try:
                submission_task_id, assignment_id = get_assignment_task_id(
                    project_id, task_type_str, api_key, env
                )
            except Exception as e:
                # Don't fall back to generating new UUIDs - this causes "Task not found" errors
                # because the backend doesn't know about these generated IDs
                raise click.ClickException(
                    f"Failed to fetch or create assignment: {e}\n"
                    f"The assignment endpoint is required for creating submissions. "
                    f"Please check that the project is properly configured and the "
                    f"API is accessible."
                ) from e

        # Fetch the feedback button info (field name and feedback_id) from project schema
        try:
            feedback_field_name, feedback_id = get_feedback_button_info(
                project_id, api_key, env
            )
        except Exception as e:
            raise click.ClickException(
                f"Failed to fetch feedback button configuration: {e}"
            ) from e

        # Request S3 pre-signed URL for upload (using assignment_id)
        try:
            presigned_response, upload_metadata = request_s3_presigned_url(
                project_id=project_id,
                task_uuid=assignment_id,
                filename=zip_filename,
                api_key=api_key,
                env=env,
            )
        except Exception as e:
            raise click.ClickException(
                f"Failed to request S3 pre-signed URL: {e}"
            ) from e

        # Upload the zip file to S3
        click.echo("\n📤 Uploading...")
        try:
            upload_to_s3(
                presigned_url=presigned_response["presignedUrl"],
                file_path=zip_path,
            )
        except Exception as e:
            raise click.ClickException(f"Failed to upload to S3: {e}") from e

        # Create feedback for the submission first
        click.echo("⏳ Running checks...")
        try:
            feedback_response = create_feedback(
                task_type_str=task_type_str,
                task_id=submission_task_id,
                feedback_id=feedback_id,
                feedback_field_name=feedback_field_name,
                s3_key=presigned_response["s3Key"],
                filename=zip_filename,
                uploaded_at=upload_metadata["uploaded_at"],
                s3_uri=presigned_response["s3Uri"],
                api_key=api_key,
                env=env,
                timeout=FEEDBACK_TIMEOUT,
            )

            # Check feedback outcome
            feedback_outcome = feedback_response.get("feedback_outcome", "UNKNOWN")
            click.echo(f"✓ Feedback completed with outcome: {feedback_outcome}")

            # Only proceed to submission if feedback passed
            if feedback_outcome != "PASS":
                # Extract feedback details from metadata.static_checks if available
                feedback_details = ""
                metadata = feedback_response.get("metadata") or {}
                static_checks = metadata.get("static_checks") or []

                if static_checks:
                    click.echo("\n📄 Feedback Details:")
                    for idx, check in enumerate(static_checks, 1):
                        check_name = check.get("name", f"Check {idx}")
                        check_status = check.get("status", "UNKNOWN")
                        full_logs = check.get("full_logs", "")

                        click.echo(f"\n   Check: {check_name}")
                        click.echo(f"   Status: {check_status}")

                        if full_logs:
                            # Show the full logs for debugging, with clear separation
                            click.echo("   Logs:")
                            click.echo("   " + "-" * 70)
                            for line in full_logs.split("\n"):
                                if line.strip():  # Skip empty lines
                                    click.echo(f"   {line}")
                            click.echo("   " + "-" * 70)

                            # Store for error message later
                            if not feedback_details:
                                feedback_details = full_logs

                # Try other possible field names if static_checks didn't have useful info
                if not feedback_details and not static_checks:
                    feedback_details = (
                        feedback_response.get("feedback_details")
                        or feedback_response.get("feedback_message")
                        or feedback_response.get("message")
                        or feedback_response.get("details")
                        or feedback_response.get("error_message")
                        or ""
                    )

                    if feedback_details:
                        click.echo("\n📄 Feedback Details:")
                        # Handle both string and dict/list feedback details
                        if isinstance(feedback_details, str):
                            for line in feedback_details.split("\n"):
                                click.echo(f"   {line}")
                        else:
                            import json

                            click.echo(f"   {json.dumps(feedback_details, indent=2)}")
                error_msg = f"Feedback did not pass (outcome: {feedback_outcome})."

                if feedback_details:
                    error_msg += "\n\nDetails:\n"
                    if isinstance(feedback_details, str):
                        for line in feedback_details.split("\n"):
                            error_msg += f"  {line}\n"
                    else:
                        import json

                        error_msg += json.dumps(feedback_details, indent=2)

                error_msg += "\n\nSubmission will not be created."
                raise click.ClickException(error_msg)

        except click.ClickException:
            raise
        except Exception as e:
            raise click.ClickException(f"Failed to create feedback: {e}") from e

        # Create submission manifest (only if feedback passed)
        click.echo("📝 Submitting...")

        # Build the submission manifest following the API structure
        # Use submission_task_id from assignment endpoint
        #
        # Note: code_difficulty_check_results and code_quality_check_results
        # are typically populated on updates after additional checks have run.
        # For initial creation, these are usually empty strings.
        #
        # checkbox_send_to_reviewer is set to:
        # - None (null) for create operations
        # - True for update operations (to send updated submission to reviewer)
        submission_manifest = {
            "submission_payload": {
                "upload_a_zip_file": {
                    "s3Key": presigned_response["s3Key"],
                    "s3Uri": presigned_response["s3Uri"],
                    "filename": zip_filename,
                    "uploadedAt": upload_metadata["uploaded_at"],
                },
                feedback_field_name: feedback_response,
                "code_difficulty_check_results": "",
                "code_quality_check_results": "",
                "checkbox_send_to_reviewer": True if submission_id else None,
                "task_type_discriminator": task_type_str,
            },
            "selected_segments": {},
            "submission_id": {"id": submission_task_id},
            "rebuttal_notes": None,
        }

        try:
            create_submission(
                submission_manifest=submission_manifest,
                api_key=api_key,
                env=env,
            )
            operation_verb = "updated" if submission_id else "created"
            click.echo(f"✓ Submission {operation_verb} successfully")
        except Exception as e:
            raise click.ClickException(f"Failed to create submission: {e}") from e

        # Write .snorkel_config file to task folder (only for create operations)
        # For updates, the file already exists and has been validated
        if not is_update:
            click.echo("\n📝 Writing .snorkel_config to task folder...")
            try:
                write_config_file(folder_path, submission_task_id)
                click.echo(
                    f"✓ Created .snorkel_config with submission_id: {submission_task_id}"
                )
            except Exception as e:
                click.echo(f"⚠️  Warning: Failed to write .snorkel_config: {e}")
                click.echo(
                    "   Submission was successful, but config file creation failed."
                )

        # Clean up zip file after successful upload
        if zip_path.exists():
            zip_path.unlink()

    except (KeyboardInterrupt, click.exceptions.Abort):
        # User cancelled - keep the zip file for inspection
        if zip_path.exists():
            click.echo(f"\n⚠️  Upload cancelled. Zip file retained at: {zip_path}")
        raise
    except Exception as e:
        # Clean up the zip file if something went wrong
        if zip_path.exists():
            zip_path.unlink()
        raise e

    return 0


@click.group()
def submissions():
    """Manage submissions"""
    pass


@submissions.command()
@click.option("--project-id", required=True, help="Project ID")
@click.option(
    "--env",
    type=click.Choice(["prod", "dev", "staging"], case_sensitive=False),
    default="prod",
    hidden=True,
    help="Environment to submit to",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Create zip file without uploading (for testing)",
)
@click.argument(
    "folder_name", type=click.Path(exists=True, file_okay=False, dir_okay=True)
)
def create(project_id, env, dry_run, folder_name):
    """Create and upload a new submission from FOLDER_NAME"""

    try:
        api_key = get_api_key()
    except ValueError as e:
        raise click.ClickException(str(e)) from e

    folder_path = Path(folder_name).resolve()

    # Check for existing .snorkel_config file to prevent duplicate submissions
    # Skip this check in dry-run mode since we're just testing and not actually submitting
    if not dry_run and config_file_exists(folder_path):
        try:
            config = read_config_file(folder_path)
            existing_submission_id = config.get("submission_id", "unknown")
            raise click.ClickException(
                f"This folder has already been submitted "
                f"(submission_id: {existing_submission_id}).\n"
                f"A submission already exists for this task folder. "
                f"If you want to update the existing submission, use "
                f"'stb submissions update' instead.\n"
                f"If you want to create a new submission, remove the "
                f".snorkel_config file first."
            )
        except ValueError:
            # If config file is malformed, still error out but with a different message
            raise click.ClickException(
                "This folder contains a .snorkel_config file that appears to be malformed.\n"
                "Please remove it if you want to create a new submission."
            ) from None

    return _process_submission(
        api_key=api_key,
        project_id=project_id,
        env=env,
        folder_path=folder_path,
        is_update=False,
        submission_id=None,
        dry_run=dry_run,
    )


@submissions.command()
@click.option("--project-id", required=True, help="Project ID")
@click.option(
    "--env",
    type=click.Choice(["prod", "dev", "staging"], case_sensitive=False),
    default="prod",
    hidden=True,
    help="Environment to submit to",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Create zip file without uploading (for testing)",
)
@click.argument(
    "folder_name", type=click.Path(exists=True, file_okay=False, dir_okay=True)
)
def update(project_id, env, dry_run, folder_name):
    """Update an existing submission with new content from FOLDER_NAME"""

    try:
        api_key = get_api_key()
    except ValueError as e:
        raise click.ClickException(str(e)) from e

    folder_path = Path(folder_name).resolve()

    # Read submission_id from .snorkel_config
    if not config_file_exists(folder_path):
        raise click.ClickException(
            "No .snorkel_config file found in the folder.\n"
            "The 'update' command requires a .snorkel_config file with a submission_id.\n"
            "Use 'stb submissions create' first to create a new submission."
        )

    try:
        config = read_config_file(folder_path)
        submission_id = config.get("submission_id", "")
        if not submission_id:
            raise click.ClickException(
                "The .snorkel_config file is missing the submission_id field.\n"
                "Please check your .snorkel_config file."
            )
        click.echo(f"📄 Using submission_id from .snorkel_config: {submission_id}")
    except ValueError as e:
        raise click.ClickException(
            f"Failed to read .snorkel_config file: {e}\n"
            f"The config file may be malformed. Please check or remove it."
        ) from e

    return _process_submission(
        api_key=api_key,
        project_id=project_id,
        env=env,
        folder_path=folder_path,
        is_update=True,
        submission_id=submission_id,
        dry_run=dry_run,
    )


@submissions.command()
@click.option(
    "--project-id",
    required=False,
    default=None,
    help="Project ID (optional - lists all submissions if not provided)",
)
@click.option(
    "--env",
    type=click.Choice(["prod", "dev", "staging"], case_sensitive=False),
    default="prod",
    hidden=True,
    help="Environment to query",
)
def list(project_id, env):
    """List your submissions (optionally filtered by project)"""

    try:
        api_key = get_api_key()
    except ValueError as e:
        raise click.ClickException(str(e)) from e

    click.echo("📋 Fetching submissions...")

    try:
        submissions = list_submission_ids(
            project_id=project_id,
            api_key=api_key,
            env=env,
        )

        if not submissions:
            click.echo("No submissions found")
        else:
            click.echo(f"Found {len(submissions)} submission(s):\n")

            # Create table header with multiple columns
            click.echo(
                "┌─────┬────────────────────────────────────────┬──────────────────────┬────────────────────────────────────────┐"
            )
            click.echo(
                "│  #  │ Submission ID                          │ Assignment State     "
                "│ Project ID                             │"
            )
            click.echo(
                "├─────┼────────────────────────────────────────┼──────────────────────┼────────────────────────────────────────┤"
            )

            # Display each submission in table format
            for idx, sub in enumerate(submissions, 1):
                # Truncate submission ID if needed
                sub_id = sub["submission_id"]
                display_id = sub_id if len(sub_id) <= 38 else f"{sub_id[:35]}..."

                # Format assignment state
                assignment_state = sub.get("assignment_state", "")[:20].ljust(20)

                # Format project ID (truncate if needed)
                proj_id = sub.get("project_id", "")
                display_proj_id = (
                    proj_id if len(proj_id) <= 38 else f"{proj_id[:35]}..."
                )
                display_proj_id = display_proj_id[:38].ljust(38)

                click.echo(
                    f"│ {idx:3d} │ {display_id:<38} │ {assignment_state} │ {display_proj_id} │"
                )

            # Table footer
            click.echo(
                "└─────┴────────────────────────────────────────┴──────────────────────┴────────────────────────────────────────┘"
            )

    except Exception as e:
        raise click.ClickException(f"Failed to list submissions: {e}") from e

    return 0
