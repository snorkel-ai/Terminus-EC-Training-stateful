Create a file called /app/hello.txt. Write "Hello, world!" to it.
