#!/bin/bash
# Oracle solution for milestone 1.
echo "Hello, world!" > /app/hello.txt
