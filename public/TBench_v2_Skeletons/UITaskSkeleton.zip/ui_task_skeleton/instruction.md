Build a simple web app at the task root (in the sandbox this is `/app`) so that the main page is served at the root URL (`/`).

The page must have:

1. **Document title** – The `<title>` must be `UI task`.
2. **Heading** – A heading (e.g. `<h1>`) with the exact text `Hello, UI task`.
3. **Button** – A button with the visible label `Click me` that can be focused when clicked.

Use static HTML (e.g. an `index.html` at the task root). The verifier will serve the task root and run unit and E2E tests against this page.
