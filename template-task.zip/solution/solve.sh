echo "Hello, world!" > hello.txt
